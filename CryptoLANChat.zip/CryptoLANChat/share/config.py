# share/config.py

HOST = "0.0.0.0"
PORT = 9000

# 32 byte AES anahtarı
ROOM_KEY = b"0123456789abcdef0123456789abcdef"
